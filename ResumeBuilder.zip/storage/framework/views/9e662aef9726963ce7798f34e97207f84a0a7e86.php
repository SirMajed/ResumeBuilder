<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-tagsinput.css')); ?>" rel="stylesheet">
    <script src="jquery-3.5.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-tagsinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-tagsinput-angular.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/corejs-typeahead/1.3.1/bloodhound.min.js" integrity="sha512-EvIw6kLsqQVDyosPz7YK2se/aTtTMs4q5LaG69ng7CukLR02uUp1CiyrL1Le/0jY6nqFAvCpjkOUPvIzTqv6UA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
      $("input:radio").attr("checked", false);
        $(document).ready(function () {

        $('input[type="radio"]').click(function () {
            if ($(this).attr("value") == "no") {
                $("#toShow").hide();
            }
            if ($(this).attr("value") == "yes") {
                $("#toShow").show();

            }
        });

        $('input[type="radio"]').trigger('click');  // trigger the event
        });



    </script>
</head>
<body>
    <div class="flex bg-white items-center justify-center  mt-32 mb-32">
        <div class="grid bg-white rounded-lg shadow-xl w-11/12 md:w-9/12 lg:w-1/2">
          <div class="flex justify-center py-4">
            <div class="flex bg-purple-200 rounded-full md:p-4 p-2 border-2 border-purple-300">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="white">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
            </div>
          </div>
      
          <div class="flex justify-center">
            <div class="flex">
              <h1 class="text-gray-600 font-bold md:text-2xl text-xl">Resume Builder</h1>
            </div>
          </div>



          <form method="POST" action="<?php echo e(action('ResumesController@store')); ?>">
            <?php echo e(csrf_field()); ?>




            <div class="grid grid-cols-1 mt-5 mx-7">
              <h2 class="uppercase text-1xl text-gray-700 font-bold">Personal information section</h2>
              <hr>
              <br>
              <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Full Name</label>
              <input name="name" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: Majed Ahmed Alghamdi" />
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 mt-5 mx-7">
              <div class="grid grid-cols-1">
                <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Birthday</label>
                <input class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" min="1970-01-01" name="birth_day" type="date" />              </div>
              <div class="grid grid-cols-1">
                <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Email Address</label>
                <input name="email" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: example@example.com" />
              </div>
            </div>

            <div class="grid grid-cols-1 mt-5 mx-7">
              <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Tell us about your self</label>
              <textarea name="bio" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"  type="text" placeholder="Who are you"> </textarea>
            </div>



          <div class="grid grid-cols-1 mt-5 mx-7">
            <h2 class="uppercase text-1xl text-gray-700 font-bold">Degree section</h2>
            <hr>
            <br>
            <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Degree</label>
            <input name="degree" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: Bachelor" />
          </div>
      
          <div class="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 mt-5 mx-7">
            <div class="grid grid-cols-1">
              <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">University Name</label>
              <input name="university" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: King Abdulaziz University" />
            </div>
            <div class="grid grid-cols-1">
              <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">GPA (out of 5)</label>
              <input name="gpa" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: 4.50" />
            </div>
          </div>
      
          
      
          <div class="grid grid-cols-1 mt-5 mx-7">
            <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Graduation Date</label>
            <input class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" min="2000-01-01" name="graduation_date" type="date" />
          </div>


        <div class="mt-5 mx-7">
          <h2 class="uppercase text-1xl text-gray-700 font-bold">Experience section</h2>
            <hr>
            <br>
        <label>Do you have previous experience?</label>
        <br>
        <input type="radio" name="hasExperience" value="yes">
        <label for="yes">Yes</label>
        <br>
        <input type="radio" name="hasExperience" value="no">
        <label for="no">No</label>
        </div>



        <div id="toShow" style='display:none'>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 mt-5 mx-7">

            <div class="grid grid-cols-1">
              <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Company Name</label>
              <input name="exp_company" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: BTC Company" />
            </div>

            <div class="grid grid-cols-1">
              <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Position Name</label>
              <input name="exp_name" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: IT Technican" />
            </div>

          </div>

          <div class="grid grid-cols-1 mt-5 mx-7">
            <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Description</label>
            <textarea name="exp_description" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"  type="text" placeholder="What did you do"> </textarea>
          </div>

        </div>


        
        <div class="grid grid-cols-1 mt-5 mx-7">
          <h2 class="uppercase text-1xl text-gray-700 font-bold">Skills section</h2>
            <hr>
            <br>
            <label style="padding-bottom: 7px;" class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Skills</label>
            <input data-role="tagsinput"  name="skills" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Seperate by (SPACE)" />
        </div>

        



        <div class="grid grid-cols-1 mt-5 mx-7">
          <h2 class="uppercase text-1xl text-gray-700 font-bold">Certificates section</h2>
          <hr>
          <br>
          <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Certificate Name</label>
          <input name="certificate_name" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: Introduction to Machine Learning" />
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 mt-5 mx-7">
          <div class="grid grid-cols-1">
            <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Issued from:</label>
            <input name="certificate_issuer" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: Cisco" />
          </div>
          <div class="grid grid-cols-1">
            <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Issued Date</label>
            <input class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" min="2000-01-01" name="certificate_date" type="date" />
          </div>
        </div>



        <div class="grid grid-cols-1 mt-5 mx-7">
          <h2 class="uppercase text-1xl text-gray-700 font-bold">Languages section</h2>
          <hr>
          <br>
          <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Native language</label>
          <input name="native_language" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: Arabic" />
        </div>

        <div class="grid grid-cols-1 mt-5 mx-7">
          <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Other language</label>
          <input name="other_language" class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" type="text" placeholder="Ex: English" />
        </div>


          





      
          <div class='flex items-center justify-center  md:gap-8 gap-4 pt-5 pb-5'>
            <button type="submit" class='w-auto bg-purple-500 hover:bg-purple-700 rounded-lg shadow-xl font-medium text-white px-4 py-2'>Create CV</button>
          </div>

        </form>

      
        </div>
      </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\ResumeBuilder\resources\views/index.blade.php ENDPATH**/ ?>