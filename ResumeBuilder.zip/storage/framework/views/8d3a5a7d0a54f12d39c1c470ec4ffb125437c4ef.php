<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css\app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css\resume.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script>
        function printCV(){
            document.getElementsByClassName("button")[0].style.visibility = "hidden";
            window.print();
            document.getElementsByClassName("button")[0].style.visibility = "";
        }
    </script>
</head>

<body>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>


    <div class="container">
        <?php if($resume->path != null): ?>
        <div class="relative w-24 h-24">
            <img class="ring-2 ring-gray-800 w-20 h-20 inline object-cover w-16 h-16 mr-2 rounded-full  border-gray-100 shadow-sm" src="images/<?php echo e($resume->path); ?>" alt="user image" />
          </div>
        <?php endif; ?>
        
        <div class="header">
            
            <div class="full-name">
                <span class="first-name"><?php echo e($resume->name); ?></span>
            </div>
            <div class="contact-info">
                <span class="email">Email: </span>
                <span class="email-val"><?php echo e($resume->email); ?></span>
                <span class="separator"></span>
                <span class="phone">Birthday: </span>
                <span class="phone-val"><?php echo e($resume->birth_day); ?></span>
            </div>

            <div class="about">
                <span class="desc">
                    <?php echo e($resume->bio); ?>

                </span>
            </div>
        </div>
        <div class="details">

            <?php if(  $resume->exp_company != null): ?>
            <div class="section">
                <div class="section__title">Experience</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name"><?php echo e($resume->exp_company); ?></div>
                            <div class="addr"><?php echo e($resume->exp_name); ?></div>
                            <div class="duration"><?php echo e($resume->exp_description); ?></div>
                        </div>
                    </div>

                </div>
            </div>
            <?php endif; ?>
            


            <div class="section">
                <div class="section__title">Education</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="name"><?php echo e($resume->university); ?></div>
                        <div class="text"><?php echo e($resume->degree); ?> | Graduated at <?php echo e($resume->graduation_date); ?></div>
                        <div class="text">GPA: <?php echo e($resume->gpa); ?></div>
                    </div>

                    <div class="section__list-item">
                        <div class="section__title">Skills</div>
                        <?php
                        // echo str_replace(",", "\r\n",   $resume->skills);
                        $skills = $resume->skills;
                        $arr = explode(",", $skills);
                        ?>
                        <ul>
                            <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="name"z><?php echo e($skill); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

            </div>
            <div class="section__title">Certificates</div>
                <div class="section__list">
                        
                    
                    <div class="section__list-item">
                        <div class="name"><?php echo e($resume->certificate_name); ?></div>
                        <div class="text"><?php echo e($resume->certificate_issuer); ?> | <?php echo e($resume->certificate_date); ?></div>
                    </div>

            <div class="section">
                <div class="section__title">
                    Languages
                </div>
                <div class="section__list">
                    <div class="section__list-item">
                        <?php echo e($resume->native_language); ?>

                        <span class="separator">|</span>
                        <?php if(  $resume->other_language != null): ?>
                        <?php echo e($resume->other_language); ?>

                        <?php endif; ?>
                        

                    </div>
                </div>
            </div>

        </div>

    </div>

    </div>

    <div class="button">
        <button onclick="printCV();" class="btn"><i class="fa fa-download"></i> Download CV</button>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\ResumeBuilder\resources\views/resume.blade.php ENDPATH**/ ?>